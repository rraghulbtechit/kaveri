package com.swissre.ipa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.swissre.ipa.model.Program;
import com.swissre.ipa.service.ProgramMgntService;

@RestController("/program")
public class ProgramMngtController {
	
	@Autowired
	private ProgramMgntService programMgntService;
	
	@PostMapping("/add")
	public String addProgram(@RequestBody Program program) throws Exception {
		return programMgntService.addProgram(program);
	}

}
