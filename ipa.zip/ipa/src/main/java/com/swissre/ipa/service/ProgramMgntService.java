package com.swissre.ipa.service;

import com.swissre.ipa.model.Program;

public interface ProgramMgntService {
	
	public String addProgram(Program program) throws Exception;

}
