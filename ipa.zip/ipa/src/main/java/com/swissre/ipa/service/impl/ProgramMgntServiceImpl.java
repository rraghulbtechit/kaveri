package com.swissre.ipa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.swissre.ipa.model.Program;
import com.swissre.ipa.service.ProgramMgntService;

@Service
public class ProgramMgntServiceImpl implements ProgramMgntService {
	
	@Autowired
	private DocumentClient documentClient;
	
	public String addProgram(Program program) throws Exception {
		documentClient.save(program);
		return "Program Added Successfully..!";
	}

}
